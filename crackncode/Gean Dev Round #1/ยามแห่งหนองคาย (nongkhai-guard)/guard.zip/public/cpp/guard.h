#include <vector>

std::vector<int> guard(int N, std::vector<int> A, std::vector<int> P);