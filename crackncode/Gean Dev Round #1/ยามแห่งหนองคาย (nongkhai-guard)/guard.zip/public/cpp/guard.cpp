#include <vector>
#include "guard.h"

std::vector<int> guard(int N, std::vector<int> A, std::vector<int> P) {
    std::vector<int> Ans(N);
    // edit this
    return Ans;
}