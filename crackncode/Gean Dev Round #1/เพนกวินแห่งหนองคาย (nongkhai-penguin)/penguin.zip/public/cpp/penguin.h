#include <vector>

void penguin(int N);
bool play(std::vector<int> A);