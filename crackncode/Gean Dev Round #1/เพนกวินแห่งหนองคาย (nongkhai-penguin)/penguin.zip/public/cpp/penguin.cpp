#include <vector>
#include "penguin.h"

void penguin(int N) {
    play({1, 2, 3});
    play({3});
    // edit this
    return;
}