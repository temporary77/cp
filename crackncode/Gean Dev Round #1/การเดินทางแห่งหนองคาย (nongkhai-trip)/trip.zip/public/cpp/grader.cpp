#include <cassert>
#include <cstdio>
#include <vector>
#include "trip.h"

signed main(int argc, const char **argv) {
    int N, Q, C;
    assert(scanf("%d%d%d", &N, &Q, &C) == 3);
    std::vector<int> W(N - 1);
    for(int i = 0; i < N - 1; i++) {
        assert(scanf("%d", &W[i]));
    }
    init_trip(N, Q, C, W);
    for(int i = 0; i < Q; i++) {
        int O;
        assert(scanf("%d", &O));
        if(O == 1){
            int G;
            assert(scanf("%d", &G));
            toggle(G);
        }else{
            int S, T, F;
            assert(scanf("%d%d%d", &S, &T, &F) == 3);
            printf("%d\n", trip(S, T, F));
        }
    }
    return 0;
}