#include <vector>
#include "trip.h"

void init_trip(int N, int Q, int C, std::vector<int> W) {
    // edit this
    return;
}

void toggle(int G) {
    // edit this
    return;
}

int trip(int S, int T, int F) {
    // edit this
    return 0LL;
}