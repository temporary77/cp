#include <vector>

void init_trip(int N, int Q, int C, std::vector<int> W);
void toggle(int G);
int trip(int S, int T, int F);