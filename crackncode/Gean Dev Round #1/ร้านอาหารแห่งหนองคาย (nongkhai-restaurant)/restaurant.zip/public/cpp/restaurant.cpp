#include <vector>
#include "restaurant.h"

long long restaurant(int N, std::vector<int> &A) {
    // edit this
    return 0LL;
}