#include <vector>

long long restaurant(int N, std::vector<int> &A);