#include <cassert>
#include <cstdio>
#include <vector>
#include "restaurant.h"

signed main(int argc, const char **argv) {
    int N;
    assert(scanf("%d", &N));
    std::vector<int> A(N);
    for(int i = 0; i < N; i++) {
        assert(scanf("%d", &A[i]));
    }
    printf("%lld", restaurant(N, A));
    return 0;
}