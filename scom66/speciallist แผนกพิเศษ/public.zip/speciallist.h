#include <vector>

std::vector<int> compute_cost(int N,
			      int M,
			      std::vector<int> P,
			      std::vector<int> X,
			      std::vector<int> Z);
