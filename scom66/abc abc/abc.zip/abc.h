#include <string>
#include <utility>

std::pair<int, int> max_unbalance(std::string S);
