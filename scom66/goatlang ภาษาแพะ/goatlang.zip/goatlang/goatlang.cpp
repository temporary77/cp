#include "goatlang.h"

std::tuple<std::vector<std::vector<int>>, int, int> example1() {
  return {{{1, 0, 0}, {0, 2, 0}, {0, 0, 3}}, 2, 2};
}
std::tuple<std::vector<std::vector<int>>, int, int> example2() {
  return {{{1, 1}, {1, 0}}, 0, 1};
}

std::tuple<std::vector<std::vector<int>>, int, int>
task1(std::vector<std::vector<int>> A, int r, int c) {
  return {{{1}}, 0, 0}; // edit this
}
std::tuple<std::vector<std::vector<int>>, int, int>
task2(std::vector<std::vector<int>> H, int a, int b) {
  return {{{1}}, 0, 0}; // edit this
}
std::tuple<std::vector<std::vector<int>>, int, int> task3(std::vector<int> a) {
  return {{{1}}, 0, 0}; // edit this
}
std::tuple<std::vector<std::vector<int>>, int, int> task4() {
  return {{{1}}, 0, 0}; // edit this
}
std::tuple<std::vector<std::vector<int>>, int, int> task5(std::vector<int> D) {
  return {{{1}}, 0, 0}; // edit this
}
std::tuple<std::vector<std::vector<int>>, int, int> task6(int m) {
  return {{{1}}, 0, 0}; // edit this
}