#include <vector>
void init(int N,std::vector<std::vector<int> > Req){
    return;
}
long long least_crowded(int P){
    return 0;
}
