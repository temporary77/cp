#include <vector>
void init(int N,std::vector<std::vector<int> > Req);
long long least_crowded(int P);
