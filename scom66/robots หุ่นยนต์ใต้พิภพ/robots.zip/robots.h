#include <string>

void init_robots(std::string S, int A, int B);

bool update(int K);
