#include "robots.h"

void init_robots(std::string s, int a, int b) {}

bool update(int k) { return false; }
