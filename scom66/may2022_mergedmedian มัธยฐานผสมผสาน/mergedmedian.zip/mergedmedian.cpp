#include "mergedmedian.h"

long long find_merged_median(int N) {
  return alice(0); 
}