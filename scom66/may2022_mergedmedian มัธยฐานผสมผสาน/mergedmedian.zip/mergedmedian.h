#include <vector>

long long find_merged_median(int N);
long long alice(int i);
long long bob(int i);