int height_threshold(int N, int Q);

bool drop_egg(int egg_number, int h);