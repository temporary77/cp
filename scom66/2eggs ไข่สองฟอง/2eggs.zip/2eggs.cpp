#include "2eggs.h"

int height_threshold(int N, int Q) {
  drop_egg(1, N - 1);
  return 1;
}