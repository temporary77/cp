#include <vector>

void initialize(int N, int Q, std::vector<std::pair<int, int>> R,
                std::vector<int> C);
long long most_expensive(int a, int b);