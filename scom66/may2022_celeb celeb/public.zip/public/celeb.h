#ifndef __CELEB_H_INCLUDED__
#define __CELEB_H_INCLUDED__

#include <vector>

std::vector<long long> max_revenue(int N, int K, 
				   std::vector<long long> X,
				   std::vector<int> M);

#endif
