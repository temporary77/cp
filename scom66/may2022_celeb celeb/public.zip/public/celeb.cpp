#include "celeb.h"

std::vector<long long> max_revenue(int N, int K, 
				   std::vector<long long> X,
				   std::vector<int> M)
{
  std::vector<long long> rev;

  for(int j=0; j<K; j++)
    rev.push_back(0);

  return rev;
}

