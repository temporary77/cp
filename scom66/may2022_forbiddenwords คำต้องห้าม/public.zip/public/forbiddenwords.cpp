#include "forbiddenwords.h"

std::vector<std::pair<int,int>> alice(int M, int N, int K, long long X, 
				      std::vector<std::pair<int,int>> F)
{
  std::vector<std::pair<int,int>> words;
  
  return words;
}


long long bob(int M, std::vector<std::pair<int,int>> W)
{
  return 0;
}

