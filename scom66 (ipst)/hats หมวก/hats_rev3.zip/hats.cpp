#include "hats.h"
#include <bits/stdc++.h>
using namespace std;

int think(int N, int id, vector<int> hats) {
	return -1;
}
