#ifndef __HATS_H_INCLUDED_
#define __HATS_H_INCLUDED_

#include <vector>

int think(int N, int id, std::vector<int> hats);

#endif