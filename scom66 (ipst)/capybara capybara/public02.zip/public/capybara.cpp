#include "capybara.h"
#include <vector>
using namespace std;

void capybara(int N, int Q, std::vector<int> M, std::vector<int> K){
  return;
}

long long travel(int A,int B){
    return 1;
}
