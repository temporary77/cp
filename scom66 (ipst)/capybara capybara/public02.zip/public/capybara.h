#ifndef __CAPYBARA_H_INCLUDED__
#define __CAPYBARA_H_INCLUDED__

#include <vector>
void capybara(int N, int Q, std::vector<int> M, std::vector<int> K);
long long travel(int A,int B);
#endif
