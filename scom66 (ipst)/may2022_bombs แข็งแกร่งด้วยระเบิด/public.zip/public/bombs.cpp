#include "bombs.h"

void initialize(int N) { return; }

long long max_hp_loss(int X, int T, int A, int P) { return 0; }
