#ifndef _BOMBS_H_
#define _BOMBS_H_

void initialize(int);
long long max_hp_loss(int, int, int, int);

#endif