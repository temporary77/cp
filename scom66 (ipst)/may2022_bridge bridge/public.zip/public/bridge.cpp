#include "bridge.h"

long long destroy_bridge(int N, std::vector<int> W)
{
  return 0;
}
