#ifndef __BRIDGE_H_INCLUDED__
#define __BRIDGE_H_INCLUDED__
#include <vector>

long long destroy_bridge(int N, std::vector<int> W);

#endif
