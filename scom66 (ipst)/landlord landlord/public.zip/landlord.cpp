#include "landlord.h"
#include <vector>
using namespace std;

void landlord(int N, int M, vector<vector<int> > K){
  return;
}

int house(int A, int B){
  return 0;
}
