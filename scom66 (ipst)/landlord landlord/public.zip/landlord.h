#ifndef __LANDLORD_H_INCLUDED__
#define __LANDLORD_H_INCLUDED__

#include <vector>
using namespace std;
void landlord(int N, int M, vector<vector<int> > K);
int house(int A, int B);

#endif
