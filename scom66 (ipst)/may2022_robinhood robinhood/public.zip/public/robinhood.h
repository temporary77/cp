#ifndef _ROBINHOOD_H_
#define _ROBINHOOD_H_

#include <vector>

void initialize(std::vector<int>, int);
int ask(int);
void add(int);

#endif