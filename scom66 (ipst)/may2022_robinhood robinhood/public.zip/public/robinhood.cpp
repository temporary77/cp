#include "robinhood.h"
#include <vector>

void initialize(std::vector<int> A, int M) {}

int ask(int V) { return 0; }

void add(int V) {}