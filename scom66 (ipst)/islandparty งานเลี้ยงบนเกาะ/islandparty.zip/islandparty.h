#include <vector>

void init(int N, int T, std::vector<long long> A, std::vector<int> u, std::vector<int> v);

long long find_drunkenness(int L, int R, int X);
