#include <vector>
#include "islandparty.h"

void init(int N, int T, std::vector<long long> A, std::vector<int> u, std::vector<int> v) {
    return;
}

long long find_drunkenness(int L, int R, int X) {
    return 0;
}
