#include <vector>

std::vector<std::vector<int>> find_matching(int N);
bool can_match(std::vector<int> B);
