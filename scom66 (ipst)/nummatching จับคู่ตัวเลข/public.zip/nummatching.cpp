#include "nummatching.h"

std::vector<std::vector<int>> find_matching(int N)
{
  std::vector<std::vector<int>> output;
  
  for(int i=0; i<N/2; i++) {
    std::vector<int> p;
    p.push_back(i*2);
    p.push_back(i*2+1);
    output.push_back(p);
  }
  return output;
}

