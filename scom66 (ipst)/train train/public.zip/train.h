#ifndef __TRAIN_H__
#define __TRAIN_H__
#include <vector>

int train(int, int, std::vector<int>, std::vector<int>, std::vector<int>,
          std::vector<int>);

#endif