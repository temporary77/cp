#include "train.h"

int train(int n, int m, std::vector<int> u, std::vector<int> v,
          std::vector<int> A, std::vector<int> B) {
  return 0;
}