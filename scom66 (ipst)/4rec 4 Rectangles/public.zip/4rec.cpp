#include <vector>
long long find_rec(std::vector<std::vector<int> > Point,int P,int Q){
    return 0;
}
