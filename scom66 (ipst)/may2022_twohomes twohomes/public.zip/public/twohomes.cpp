#include "twohomes.h"

std::pair<int,int> find_homes(int N, int M,
			      std::vector<std::vector<int>> R)
{
  return std::make_pair(0,0);
}
