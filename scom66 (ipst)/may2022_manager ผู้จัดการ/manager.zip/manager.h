#ifndef __MANAGER_H_INCLUDED__
#define __MANAGER_H_INCLUDED__

#include <vector>

void initialize(int N, int Q, std::vector<int> A);
int min_managers(int L, int R, int X);

#endif
