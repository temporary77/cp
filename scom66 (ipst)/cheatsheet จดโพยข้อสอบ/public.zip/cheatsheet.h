#include <vector>
std::vector<int> write_cheatsheet(int N, std::vector<int> A);
std::vector<int> recover_answer(int N, std::vector<int> R);
