#include "company.h"
#include <vector>
void init(int N, int M,std::vector<int> C, std::vector<std::vector<int> > Road)
{
    return;
}
std::vector<int> dissolve(std::vector<std::vector<int> > Group)
{
    std::vector<int>ans;
    return ans;
}
