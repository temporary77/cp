#include "lonelytown.h"
#include <vector>

void init_town(int N, int Q, std::vector<int> u, std::vector<int> v) {
    return ;
}

void change_edge(int x, int y, int z) {
    return ;
}

int lonelytown_query() {
    return 0;
}

int simulate_query(int e) {
    return 0;
}
