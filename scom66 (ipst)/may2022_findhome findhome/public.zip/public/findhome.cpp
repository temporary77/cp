#include "findhome.h"

int find_home(int N, int M, std::vector<std::pair<int,int>> R)
{
  return 0;
}
