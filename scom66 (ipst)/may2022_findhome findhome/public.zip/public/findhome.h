#ifndef __FINDHOME_H_INCLUDED__
#define __FINDHOME_H_INCLUDED__

#include <vector>

int find_home(int N, int M, std::vector<std::pair<int,int>> R);

int check(int u);

#endif
