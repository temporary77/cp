#include <vector>

std::vector<int> updown(int N, int M, std::vector<int> U, std::vector<int> V);